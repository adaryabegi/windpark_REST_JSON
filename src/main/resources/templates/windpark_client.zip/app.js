const express = require("express");
const app = express();
const path = require("path");
const router = express.Router();
const fetch = require("node-fetch");
const isAfter = require("date-fns/isAfter");
const isBefore = require("date-fns/isBefore");
const { isSameDay } = require("date-fns");

app.set("view engine", "pug");
app.set("views", path.join(__dirname, "views"));
// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded());
app.use(express.static(__dirname + "/public"));
const alldata = [];

// Parse JSON bodies (as sent by API clients)
app.use(express.json());
router.get("/", function (req, res) {
  res.render("index");
});

router.post("/", function (req, res) {
  const { windkraftID, von, bis, nach } = req.body;

  if (windkraftID) {
    fetch(`http://localhost:8080/windengine/${windkraftID}/json?mediaType=json`)
      .then((res) => res.text())
      .then((text) => {
        var fetchedData = JSON.parse(text);
        var keyNames = [];
        for (const [key, value] of Object.entries(fetchedData)) {
          keyNames.push(key);
        }
        keyNames.shift(); // remove first item bc it is already set (static)
        alldata.push(fetchedData);
        if (von && bis) {
          const filteredData = alldata.filter((item) => {
            var timy = new Date(item.timestamp);
            var vonDate = new Date(von);
            var bisDate = new Date(bis);
            return (
              (isAfter(timy, vonDate) && isBefore(timy, bisDate)) ||
              isSameDay(vonDate, timy) ||
              isSameDay(bisDate, timy)
            );
          });

          res.render("index", {
            data: filteredData,
            keyNames,
            von,
            bis,
            nach: null,
          });
        } else if (nach) {
          const filteredData = alldata.filter((item) => {
            var timy = new Date(item.timestamp);
            var nachDate = new Date(nach);

            return isAfter(timy, nachDate) || isSameDay(nachDate, timy);
          });
          res.render("index", {
            data: filteredData,
            keyNames,
            von: null,
            bis: null,
            nach,
          });
        } else {
          res.render("index", { data: alldata, keyNames });
        }
      });
  } else if (von && bis) {
    var keyNames = [];
    if (alldata.length > 0) {
      for (const [key, value] of Object.entries(alldata[0])) {
        keyNames.push(key);
      }
      keyNames.shift();
    }
    const filteredData = alldata.filter((item) => {
      var timy = new Date(item.timestamp);
      var vonDate = new Date(von);
      var bisDate = new Date(bis);
      return (
        (isAfter(timy, vonDate) && isBefore(timy, bisDate)) ||
        isSameDay(vonDate, timy) ||
        isSameDay(bisDate, timy)
      );
    });

    res.render("index", { data: filteredData, keyNames, von, bis, nach: null });
  } else if (nach) {
    var keyNames = [];
    if (alldata.length > 0) {
      for (const [key, value] of Object.entries(alldata[0])) {
        keyNames.push(key);
      }
      keyNames.shift();
    }
    const filteredData = alldata.filter((item) => {
      var timy = new Date(item.timestamp);
      var nachDate = new Date(nach);

      return isAfter(timy, nachDate) || isSameDay(nachDate, timy);
    });
    res.render("index", {
      data: filteredData,
      keyNames,
      von: null,
      bis: null,
      nach,
    });
  } else {
    res.render("index");
  }
});

//add the router
app.use("/", router);
app.listen(process.env.port || 3000);

console.log("Running at Port 3000");
